#ifndef __STRATEGYMEANREVERSE__
#define __STRATEGYMEANREVERSE__

#include <deque>
#include <iostream>
#include <unordered_map>
#include <unordered_set>
#include <queue>
#include <string>
#include <stdio.h>
#include <unordered_map>
#include <vector>
#include <list>
#include <sstream>
#include <algorithm>
#include <sstream>
#include <fstream>
#include <memory>
#include <cmath>
#include <thread>
#include <set>

#include <algorithm>
#include <iostream>
#include <cstring>
#include <fstream>
#include "rapidjson/document.h"
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"
#include <rapidjson/istreamwrapper.h>
#include <rapidjson/ostreamwrapper.h>


#include "cxxopts.hpp"
#include "Log.h"
#include "Timer.h"


#include "../include/strategy.h"

#include "cxxopts.hpp"

using namespace rapidjson;
using namespace std;

namespace BackTraderCN {


	struct instrument_parameter
	{
		std::string source_id;
		std::string account_id;
		//合约代码
		std::string instrument_id;
		//交易所代码
		std::string exchange_id;
		//价格单位
		double tick_price{ 0 };
		//每次交易量1--尚未处理部分成交
		int trade_volume{ 0 };
		//合约乘数
		int contract_multiplier{ 0 };
		//观察的tick数量
		int watch_tick_numbers{ 0 };

		char trading_day[DATE_LEN];                 //交易日
		//持续上升
		double continues_up{ 0 };
		//上升到多少百分百就不做了
		double up_stop_limit{ 0 };
		
		//持续下跌
		double continues_down{ 0 };
		//下跌到多少百分百就不做了
		double down_stop_limit{ 0 };

		//等到多少秒后不成交则撤单
		int waiting_for_seconds_then_cancel{ 0 };

		//止盈设置的tick price数量(跳数),默认赚1跳的价格
		int take_profit_of_tick_price_count{ 1 };
		//止损设置的tick price数量(跳数)
		int stop_loss_of_tick_price_count{ 0 };
		
		//策略安全定位,超过这个价就不开仓了
		double instrument_up_limit{ 0 };
		//策略安全定位,超过这个价就不开仓了
		double instrument_low_limit{ 0 };
		
		//["09:00:00","13:30:00", "21:00:00"],
		std::vector<std::string> market_start_time;
		//["11:25:00","14:55:00", "22:55:00"]
		std::vector<std::string> market_close_time;
		//允许买开卖平
		bool buy_open_active = true;
		//允许卖开买平
		bool sell_open_active = true;
		
		//中间价
		//指向最近一个数据.last_index结合watch_tick_numbers做成循环数组
		vector<double> mid_prices;
		int last_index = 0;
	};

	struct OrderInfo
	{
		std::set<uint64_t> order_id_set;
		uint64_t order_id = 0;
		std::string instrument_id;
		std::string account_id;
		std::string exchange_id;
		OrderStatus status = OrderStatusUnknown;
		Side side = 0;
		Offset offset = 0;

		double price = 0;
		int total_qty = 0;
		int trade_qty = 0;
		int remain_qty = 0;

	};

	class StrategyMeanReverse : public BackTraderCN::Strategy
	{
	public:
		StrategyMeanReverse(const std::string &name, std::map <std::string, std::string> &config_str,
			std::map<std::string, int> &config_int,
			std::map<std::string, double> &config_double) : Strategy(name, config_str, config_int,
				config_double)
		{

		};


		~StrategyMeanReverse();

	public:
		virtual void init();

		void on_quote(const Quote &quote);
		void on_entrust(const Entrust &entrust) {};
		void on_transaction(const Transaction &transaction) {};

		void on_position(const Position &pos);
		void on_order(const Order &order);
		void on_trade(const Trade &trade);

		double round_to_pricetick(double, double);

		bool if_market_closing(const Quote& quote, instrument_parameter &params);
		//std::pair 可以打包最多两个值到一个类里,常用在需要返回两个值的函数里
		// 如果要存储超过2个不同类型的对象, 可以使用 std::tuple, 它能存储最多10个不同对象类型.
		std::pair<double, double> checkMaxContinuesUpOrDown(const Quote& quote, instrument_parameter &params);

		void handler_stop_loss(const Quote &quote, instrument_parameter &params, bool force_close_now = false);

	public:

		bool load(string& config_file_path, string& param_file_path)
		{
			return load_config(config_file_path) && load_params(param_file_path);
		};

	private:
		std::vector<std::string> td_sources;
		std::vector<std::string> td_accounts;

		std::vector<std::string> instrument_ids;

		string config_file_path;
		string param_file_path;

		//记录设置参数
		//<instrument_id, >
		std::unordered_map<std::string, instrument_parameter> instrument_parameters;
		//<order_id, >
		std::unordered_map<uint64_t, OrderInfo> order_id_to_order_map;
		// pending close: <buy,>   <sell, >
		//<Side ,>
		std::unordered_map<Side, OrderInfo> pending_close_order_map;
		
	private:

		bool load_config(string& config_file_path);
		bool load_params(string& param_file_path);

	protected:
		//用作开关控制，TD 连接不上时，不发送marketData给sc
		bool td_connected;

	};


}
#endif