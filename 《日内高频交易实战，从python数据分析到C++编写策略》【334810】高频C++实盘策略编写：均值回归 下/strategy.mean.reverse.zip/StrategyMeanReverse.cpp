#include "StrategyMeanReverse.h"


namespace BackTraderCN {


	StrategyMeanReverse::~StrategyMeanReverse()
	{
	}

	bool StrategyMeanReverse::load_config(string& config_file)
	{
		Document docRead;
		ifstream ifs(config_file);
		IStreamWrapper isw(ifs);
		docRead.ParseStream(isw);
		if (docRead.HasParseError()) {
			std::cerr << "config file parse error:" << config_file << std::endl;
			return false;
		}

		

		if (docRead.HasMember("MeanReverse") && docRead["MeanReverse"].IsArray())
		{
			const rapidjson::Value& instrument_array = docRead["MeanReverse"];
			size_t len = instrument_array.Size();
			for (size_t i = 0; i < len; i++) {
				const rapidjson::Value& instrument_param = instrument_array[i];

				std::string instrument_id = "";
				if (instrument_param.HasMember("instrument_id"))
				{
					instrument_id = instrument_param["instrument_id"].GetString();
					SPDLOG_INFO("instrument_id is {}", instrument_id.c_str());
					instrument_ids.push_back(instrument_id);
				}
				instrument_parameters[instrument_id].instrument_id = instrument_id;

				if (instrument_param.HasMember("source"))
				{
					instrument_parameters[instrument_id].source_id = instrument_param["source"].GetString();
					SPDLOG_INFO("source_id is {}", instrument_parameters[instrument_id].source_id);
					td_sources.push_back(instrument_parameters[instrument_id].source_id);
				}

				if (instrument_param.HasMember("account_id"))
				{
					instrument_parameters[instrument_id].account_id = instrument_param["account_id"].GetString();
					SPDLOG_INFO("account_id is {}", instrument_parameters[instrument_id].account_id);
					td_accounts.push_back(instrument_parameters[instrument_id].account_id);
				}

				std::string exchange_id = "";
				if (instrument_param.HasMember("exchange_id"))
				{
					exchange_id = instrument_param["exchange_id"].GetString();
					SPDLOG_INFO("exchange_id is {}", exchange_id.c_str());
				}

				instrument_parameters[instrument_id].exchange_id = exchange_id;

				if (instrument_param.HasMember("tick_price"))
				{
					instrument_parameters[instrument_id].tick_price = instrument_param["tick_price"].GetDouble();
					SPDLOG_INFO("tick_price is {:.10f}", instrument_parameters[instrument_id].tick_price);
				}

				if (instrument_param.HasMember("trade_volume"))
				{
					instrument_parameters[instrument_id].trade_volume = instrument_param["trade_volume"].GetInt();
					SPDLOG_INFO("trade_volume is {}", instrument_parameters[instrument_id].trade_volume);
				}

				if (instrument_param.HasMember("contract_multiplier"))
				{
					instrument_parameters[instrument_id].contract_multiplier = instrument_param["contract_multiplier"].GetInt();
					SPDLOG_INFO("contract_multiplier is {}", instrument_parameters[instrument_id].contract_multiplier);
				}

				if (instrument_param.HasMember("watch_tick_numbers"))
				{
					instrument_parameters[instrument_id].watch_tick_numbers = instrument_param["watch_tick_numbers"].GetInt();
					SPDLOG_INFO("watch_tick_numbers is {}", instrument_parameters[instrument_id].watch_tick_numbers);
				}

				if (instrument_param.HasMember("continues_up"))
				{
					instrument_parameters[instrument_id].continues_up = instrument_param["continues_up"].GetDouble();
					SPDLOG_INFO("continues_up is {}", instrument_parameters[instrument_id].continues_up);
				}
				if (instrument_param.HasMember("up_stop_limit"))
				{
					instrument_parameters[instrument_id].up_stop_limit = instrument_param["up_stop_limit"].GetDouble();
					SPDLOG_INFO("up_stop_limit is {}", instrument_parameters[instrument_id].up_stop_limit);
				}

				if (instrument_param.HasMember("continues_down"))
				{
					instrument_parameters[instrument_id].continues_down = instrument_param["continues_down"].GetDouble();
					SPDLOG_INFO("continues_down is {}", instrument_parameters[instrument_id].continues_down);
				}
				if (instrument_param.HasMember("down_stop_limit"))
				{
					instrument_parameters[instrument_id].down_stop_limit = instrument_param["down_stop_limit"].GetDouble();
					SPDLOG_INFO("down_stop_limit is {}", instrument_parameters[instrument_id].down_stop_limit);
				}

				if (instrument_param.HasMember("waiting_for_seconds_then_cancel"))
				{
					instrument_parameters[instrument_id].waiting_for_seconds_then_cancel = instrument_param["waiting_for_seconds_then_cancel"].GetInt();
					SPDLOG_INFO("waiting_for_seconds_then_cancel is {}", instrument_parameters[instrument_id].waiting_for_seconds_then_cancel);
				}

				if (instrument_param.HasMember("take_profit_of_tick_price_count"))
				{
					instrument_parameters[instrument_id].take_profit_of_tick_price_count = instrument_param["take_profit_of_tick_price_count"].GetInt();
					SPDLOG_INFO("take_profit_of_tick_price_count is {}", instrument_parameters[instrument_id].take_profit_of_tick_price_count);
				}

				if (instrument_param.HasMember("stop_loss_of_tick_price_count"))
				{
					instrument_parameters[instrument_id].stop_loss_of_tick_price_count = instrument_param["stop_loss_of_tick_price_count"].GetInt();
					SPDLOG_INFO("stop_loss_of_tick_price_count is {}", instrument_parameters[instrument_id].stop_loss_of_tick_price_count);
				}
				
				if (instrument_param.HasMember("market_start_time") && instrument_param["market_start_time"].IsArray())
				{
					const rapidjson::Value& market_start_time_array = instrument_param["market_start_time"];
					size_t len = market_start_time_array.Size();
					for (size_t i = 0; i < len; i++) {
						instrument_parameters[instrument_id].market_start_time.push_back(market_start_time_array[i].GetString());
					}
				}

				for (auto& v : instrument_parameters[instrument_id].market_start_time) {
					SPDLOG_INFO("market_start_time is {}", v.c_str());
				}

				if (instrument_param.HasMember("market_close_time") && instrument_param["market_close_time"].IsArray())
				{
					const rapidjson::Value& market_close_time_array = instrument_param["market_close_time"];
					size_t len = market_close_time_array.Size();
					for (size_t i = 0; i < len; i++) {
						instrument_parameters[instrument_id].market_close_time.push_back(market_close_time_array[i].GetString());
					}
				}

				for (auto& v : instrument_parameters[instrument_id].market_close_time) {
					SPDLOG_INFO("market_close_time is {}", v.c_str());
				}

			}
		}

		return true;
	}

	bool StrategyMeanReverse::load_params(string& config_file)
	{
		return true;
	}


	void StrategyMeanReverse::init()
	{
		std::vector<std::string> instrument_vec;
		instrument_vec.assign(instrument_ids.begin(), instrument_ids.end());
		//MD
		std::vector<std::string>::iterator md_sources_itr;
		for (md_sources_itr = td_sources.begin(); md_sources_itr != td_sources.end(); md_sources_itr++) {
			add_md(*md_sources_itr);
			subscribe(*md_sources_itr, instrument_vec, "");
		}

		//TD
		for (int i = 0; i < td_sources.size(); i++) {
			add_account(td_sources[i], td_accounts[i], 10000.0);
		}

		td_connected = false;
	}


	double StrategyMeanReverse::round_to_pricetick(double price, double pricetick)
	{
		return std::round(price / pricetick) * pricetick;
	}



	bool StrategyMeanReverse::if_market_closing(const Quote& quote, instrument_parameter &params) {
		bool is_market_active = false;
		int time_size = params.market_start_time.size();

		std::string quote_date_time =
			NanoTimer::getInstance()->parseNano(quote.data_time, "%H:%M:%S");

		for (int i = 0; i < time_size; i++) {
			if (strcmp(quote_date_time.c_str(), params.market_start_time[i].c_str()) >= 0 &&
				strcmp(quote_date_time.c_str(), params.market_close_time[i].c_str()) <= 0) {
				is_market_active = true;
			}
			if (is_market_active) {
				break;
			}
		}

		return !is_market_active;
	}


	std::pair<double, double> StrategyMeanReverse::checkMaxContinuesUpOrDown(const Quote& quote, instrument_parameter &params)
	{
		if (quote.last_price > params.instrument_up_limit ||
			quote.last_price < params.instrument_low_limit) {
			return std::make_pair(0, 0);
		}

		if (params.mid_prices.size() < params.watch_tick_numbers)
		{
			double mid_price = (quote.ask_price[0] + quote.bid_price[0]) / 2;
			//更新last的价格
			params.mid_prices.push_back(mid_price);
			params.last_index = params.mid_prices.size();
			return std::make_pair(0, 0);
		}
		else {
			params.last_index = params.last_index % params.watch_tick_numbers;
			double mid_price = (quote.ask_price[0] + quote.bid_price[0]) / 2;
			
			SPDLOG_DEBUG("[on_quote] last_index {} ",params.last_index);
			vector<double>::iterator max_v = max_element(params.mid_prices.begin(), params.mid_prices.end());
			vector<double>::iterator min_v = min_element(params.mid_prices.begin(), params.mid_prices.end());

			double max_price_diff = mid_price - *min_v;
			double min_price_diff = *max_v - mid_price;
			
			params.mid_prices[params.last_index++ % params.watch_tick_numbers] = mid_price;

			return std::make_pair(max_price_diff, min_price_diff);
		}
		
		return std::make_pair(0, 0);
	}

	void StrategyMeanReverse::on_quote(const Quote &quote)
	{
		//可以过滤非开盘时间的乱数据，也过滤一开盘只有挂单变动却没有成交那段时间的tick
		if (quote.volume == 0) {
			return;
		}

		auto& params = instrument_parameters[quote.instrument_id];
		//换日重置
		if (strcmp(params.trading_day, quote.trading_day) != 0) {
			SPDLOG_DEBUG("[on_quote] (change day?) {} {}"
				, quote.trading_day
				, quote.data_time);
			//设置允许开仓的上下空间
			params.instrument_low_limit = quote.pre_close_price * (1 - abs(params.down_stop_limit));
			params.instrument_up_limit = quote.pre_close_price * (1 + abs(params.up_stop_limit));
			
			params.mid_prices.clear();
			strncpy(params.trading_day, quote.trading_day, DATE_LEN);
		}

		if (if_market_closing(quote, params)) {
			handler_stop_loss(quote, params, true);
		}

		std::pair<double, double> maxContinuesUpOrDown = checkMaxContinuesUpOrDown(quote, params);
		
		std::string quote_date_time =
			NanoTimer::getInstance()->parseNano(quote.data_time, "%H:%M:%S");
		SPDLOG_DEBUG("[on_quote] {} (instrument_id) {} (last_price) {} (maxContinuesUp) {} (maxContinuesDown) {} "
			, quote_date_time
			, quote.instrument_id
			, quote.last_price
			, maxContinuesUpOrDown.first
			, maxContinuesUpOrDown.second);

		//可以sell open,continues_up值有效 > 0,连续上升达到极致,卖开
		if (params.sell_open_active & params.continues_up > 0 && maxContinuesUpOrDown.first > params.continues_up) {
			
			uint64_t order_id = this->get_util()->insert_fok_order(
				params.instrument_id,
				std::string(params.exchange_id),
				params.account_id,
				quote.ask_price[0],
				params.trade_volume,
				SideSell, OffsetOpen);
			//send order
			if (order_id != -1)
			{
				OrderInfo& order = order_id_to_order_map[order_id];
				order.order_id = order_id;
				order.order_id_set.insert(order_id);
				order.account_id = params.account_id;
				order.instrument_id = params.instrument_id;
				order.exchange_id = params.exchange_id;
				order.status = OrderStatusSubmitted;
				order.side = SideSell;
				order.offset = OffsetOpen;
				order.price = quote.ask_price[0];
				order.total_qty = params.trade_volume;
				order.remain_qty = params.trade_volume;
				order.trade_qty = 0;

				SPDLOG_DEBUG("[on_quote] insert_fok_order Sell,Open of instrument_id {} order_id {} price {:.10f}",
					order.instrument_id, order_id, quote.ask_price[0]);
				//防止连续下单
				params.sell_open_active = false;
			}
			else {
				SPDLOG_ERROR("[on_quote] insert_fok_order error. order_id: {} waiting next tick", order_id);
			}
		}
		//可以buy open,continues_down值有效 < 0,连续下跌达到极致,买开
		else if (params.buy_open_active & params.continues_down < 0 && maxContinuesUpOrDown.second < params.continues_down) {
			//连续下跌达到极致,在底部买入
			
			uint64_t order_id = this->get_util()->insert_fok_order(
				params.instrument_id,
				std::string(params.exchange_id),
				params.account_id,
				quote.bid_price[0],
				params.trade_volume,
				SideBuy, OffsetOpen);
			//send order
			if (order_id != -1)
			{
				OrderInfo& order = order_id_to_order_map[order_id];
				order.order_id = order_id;
				order.order_id_set.insert(order_id);
				order.account_id = params.account_id;
				order.instrument_id = params.instrument_id;
				order.exchange_id = params.exchange_id;
				order.status = OrderStatusSubmitted;
				order.side = SideBuy;
				order.offset = OffsetOpen;
				order.price = quote.bid_price[0];
				order.total_qty = params.trade_volume;
				order.remain_qty = params.trade_volume;
				order.trade_qty = 0;

				SPDLOG_DEBUG("[on_quote] insert_fok_order Buy,Open of instrument_id {} order_id {} price {:.10f}",
					order.instrument_id, order_id, quote.bid_price[0]);
				//防止连续下单
				params.buy_open_active = false;
			}
			else {
				SPDLOG_ERROR("[on_quote] insert_fok_order error. order_id: {} waiting next tick", order_id);
			}
		}

		handler_stop_loss(quote, params);
	}

	void StrategyMeanReverse::on_position(const Position &pos)
	{
		td_connected = true;

	}

	void StrategyMeanReverse::on_order(const Order &order)
	{
		SPDLOG_INFO("[on_order] instrument_id {}, order_id {}, side {}, offset {}, status {}, volume {}, limit_price {:.10f}"
			, order.instrument_id
			, order.order_id
			, getSide(order.side)
			, getOffset(order.offset)
			, getOrderStatus(order.status)
			, order.volume
			, order.limit_price);


		auto iter = order_id_to_order_map.find(order.order_id);
		if (iter == order_id_to_order_map.end())
		{
			SPDLOG_ERROR("[on_order] instrument_id {}, "
				"order_id {}, unknown order", order.instrument_id, order.order_id);
			return;
		}
		auto& params = instrument_parameters[order.instrument_id];
		//更新信息
		auto& orderInfo = iter->second;
		orderInfo.status = order.status;
		orderInfo.remain_qty = order.volume_left;
		orderInfo.trade_qty = order.volume_traded;

		if (OrderStatusError == order.status) {
			order_id_to_order_map.erase(order.order_id);
			//如果开仓失败,清除标记
			if (OffsetOpen == order.offset) {
				if (SideSell == order.side) {
					params.sell_open_active = true;
				}
				if (SideBuy == order.side) {
					params.buy_open_active = true;
				}
			}
			else {
				//如果平仓失败
				SPDLOG_ERROR("[on_order] instrument_id {}, order_id {},  CLOSE ERROR ", order.instrument_id, order.order_id);
			}
		}

		if (OrderStatusFilled == order.status) {
			if (OffsetOpen == order.offset) {
				//buy open/sell open
				Offset close_type = OffsetClose;
				if ("SHFE" == order.exchange_id) {
					close_type = OffsetCloseToday;
				}

				if (order.side == SideSell) {
					//traded order is sell open, will create buy close
					double buy_price = orderInfo.price - params.take_profit_of_tick_price_count * params.tick_price;
					buy_price = round_to_pricetick(buy_price, params.tick_price);
					uint64_t order_id = this->get_util()->insert_limit_order(
						orderInfo.instrument_id,
						std::string(orderInfo.exchange_id),
						orderInfo.account_id,
						buy_price,
						orderInfo.trade_qty,
						SideBuy, close_type);

					//send order
					if (order_id != -1)
					{
						OrderInfo& def_up_order = order_id_to_order_map[order_id];
						def_up_order.order_id = order_id;
						def_up_order.account_id = orderInfo.account_id;
						def_up_order.instrument_id = orderInfo.instrument_id;
						def_up_order.exchange_id = orderInfo.exchange_id;
						def_up_order.status = OrderStatusSubmitted;
						def_up_order.side = SideBuy;
						def_up_order.offset = OffsetClose;
						def_up_order.price = buy_price;
						def_up_order.total_qty = orderInfo.trade_qty;
						def_up_order.remain_qty = orderInfo.trade_qty;
						def_up_order.trade_qty = 0;

						pending_close_order_map[def_up_order.side] = def_up_order;
						SPDLOG_DEBUG("[on_order] insert_limit_order  SideBuy, Close instrument_id {} order_id {}, price {:.10f}",
							def_up_order.instrument_id.c_str(), order_id, def_up_order.price);
			
					}
					else {
						SPDLOG_ERROR("[on_order] instrument_id {}, order_id {}, SEND CLOSE ERROR"
							, order.instrument_id
							, order.order_id);
					}
				}
				else {
					//traded order is buy open, will create sell close
					double sell_price = orderInfo.price + params.take_profit_of_tick_price_count * params.tick_price;
					sell_price = round_to_pricetick(sell_price, params.tick_price);
					uint64_t order_id = this->get_util()->insert_limit_order(
						orderInfo.instrument_id,
						std::string(orderInfo.exchange_id),
						orderInfo.account_id,
						sell_price,
						orderInfo.trade_qty,
						SideSell, close_type);

					//send order
					if (order_id != -1)
					{
						OrderInfo& def_up_order = order_id_to_order_map[order_id];
						def_up_order.order_id = order_id;
						def_up_order.account_id = orderInfo.account_id;
						def_up_order.instrument_id = orderInfo.instrument_id;
						def_up_order.exchange_id = orderInfo.exchange_id;
						def_up_order.status = OrderStatusSubmitted;
						def_up_order.side = SideSell;
						def_up_order.offset = OffsetClose;
						def_up_order.price = sell_price;
						def_up_order.total_qty = orderInfo.trade_qty;
						def_up_order.remain_qty = orderInfo.trade_qty;
						def_up_order.trade_qty = 0;

						pending_close_order_map[def_up_order.side] = def_up_order;
						SPDLOG_DEBUG("[on_order] insert_limit_order  SideSell, Close instrument_id {} order_id {}, price {:.10f}",
							def_up_order.instrument_id.c_str(), order_id, def_up_order.price);
			
					}
					else {
						SPDLOG_ERROR("[on_order] instrument_id {}, order_id {}, SEND CLOSE ERROR"
							, order.instrument_id
							, order.order_id);
					}
				}

			}
			else {
				//close done
				if (OffsetOpen != orderInfo.offset) {
					if (SideSell == orderInfo.side) {
						params.buy_open_active = true;//卖平已经发生,又可以买开了
						pending_close_order_map.erase(orderInfo.side);
						SPDLOG_DEBUG("[on_order] receive sell close. buy_open_active again.");
					}
					if (SideBuy == orderInfo.side) {
						params.sell_open_active = true;//买平已经发生,又可以卖开了
						pending_close_order_map.erase(orderInfo.side);
						SPDLOG_DEBUG("[on_order] receive buy close. sell_open_active again.");
					}
				}
			}

			order_id_to_order_map.erase(order.order_id);
		}
	}

	void StrategyMeanReverse::on_trade(const Trade &trade)
	{
	}

	void StrategyMeanReverse::handler_stop_loss(const Quote &quote, instrument_parameter &params, bool force_close_now)
	{
		if (pending_close_order_map.size() == 0) {
			return;
		}
		
		OrderInfo& buy_closing_order = pending_close_order_map[SideBuy];
		if (buy_closing_order.price > 1) {
			//has data
			if (force_close_now || buy_closing_order.price + params.stop_loss_of_tick_price_count * params.tick_price < quote.ask_price[0]) {
				SPDLOG_DEBUG("[handler_stop_loss] buy_closing_order.price {}, quote.ask_price[0] {} params.stop_loss_of_tick_price_count {}, params.tick_price {:.10f}",
					buy_closing_order.price, quote.ask_price[0], params.stop_loss_of_tick_price_count, params.tick_price);
				//stop loss
				int take_loss_more_tick_prices = 5;
				double buy_price = quote.ask_price[0] + take_loss_more_tick_prices * params.tick_price;
				if (buy_price > quote.upper_limit_price) {
					buy_price = quote.upper_limit_price;
				}

				this->cancel_order(buy_closing_order.order_id);
				SPDLOG_DEBUG("[handler_stop_loss] cancel_order");
				//done use market_order_close
				uint64_t order_id = this->get_util()->insert_limit_order(
					buy_closing_order.instrument_id,
					std::string(buy_closing_order.exchange_id),
					buy_closing_order.account_id,
					buy_price,
					buy_closing_order.trade_qty,
					buy_closing_order.side, buy_closing_order.offset);
				
				if (order_id != -1)
				{
					pending_close_order_map.erase(SideBuy);
					SPDLOG_DEBUG("[handler_stop_loss] insert_limit_order  SideSell, Close instrument_id {} order_id {}, price {:.10f}",
						buy_closing_order.instrument_id.c_str(), order_id, buy_price);
				}
			}
		}


		OrderInfo& sell_closing_order = pending_close_order_map[SideSell];
		if (sell_closing_order.price > 1) {
			//has data
			if (force_close_now || sell_closing_order.price - params.stop_loss_of_tick_price_count * params.tick_price > quote.bid_price[0]) {
				SPDLOG_DEBUG("[handler_stop_loss] sell_closing_order.price {}, quote.bid_price[0] {} params.stop_loss_of_tick_price_count {}, params.tick_price {:.10f}",
					sell_closing_order.price, quote.bid_price[0], params.stop_loss_of_tick_price_count, params.tick_price);
				//stop loss
				int take_loss_more_tick_prices = 5;
				double sell_price = quote.bid_price[0] - take_loss_more_tick_prices * params.tick_price;
				if (sell_price < quote.lower_limit_price) {
					sell_price = quote.lower_limit_price;
				}

				this->cancel_order(sell_closing_order.order_id);
				SPDLOG_DEBUG("[handler_stop_loss] cancel_order");
				//done use market_order_close
				uint64_t order_id = this->get_util()->insert_limit_order(
					sell_closing_order.instrument_id,
					std::string(sell_closing_order.exchange_id),
					sell_closing_order.account_id,
					sell_price,
					sell_closing_order.trade_qty,
					sell_closing_order.side, sell_closing_order.offset);

				if (order_id != -1)
				{
					pending_close_order_map.erase(SideSell);
					SPDLOG_DEBUG("[handler_stop_loss] insert_limit_order  SideSell, Close instrument_id {} order_id {}, price {:.10f}",
						sell_closing_order.instrument_id.c_str(), order_id, sell_price);
				}
			}
		}
	}
}