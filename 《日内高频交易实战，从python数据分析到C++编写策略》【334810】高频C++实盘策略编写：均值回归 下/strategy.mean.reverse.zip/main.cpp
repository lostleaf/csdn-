#include <deque>
#include <iostream>
#include <unordered_map>
#include <unordered_set>
#include <queue>
#include <string>
#include <stdio.h>
#include <unordered_map>
#include <vector>
#include <list>
#include <sstream>
#include <algorithm>
#include <sstream>
#include <fstream>
#include <memory>
#include <cmath>
#include <thread>
#include <set>


#include <iostream>
#include <cstring>
#include <fstream>
#include "rapidjson/document.h"
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"
#include <rapidjson/istreamwrapper.h>
#include <rapidjson/ostreamwrapper.h>


#include "cxxopts.hpp"

#include "Timer.h"

#include "StrategyMeanReverse.h"
#include "../include/strategy.h"

using namespace rapidjson;
using namespace std;


int main(int argc, char *argv[])
{
	cxxopts::Options options("Strategy Service");
	options
		.positional_help("[optional args]")
		.show_positional_help();
	options.add_options()
		("log-level", "log level", cxxopts::value<int>()->default_value("0"))
		("p,parameter", "parameter file", cxxopts::value<std::string>()->default_value("./StrategyMeanReverse_parameter.json"))
		("f,file", "Config Json File name", cxxopts::value<std::string>()->default_value("./StrategyMeanReverse_config.json"));

	auto result = options.parse(argc, argv);

	std::map<std::string, std::string> config_str;
	std::map<std::string, int> config_int;
	std::map<std::string, double> config_double;

	int log_level = result["log-level"].as<int>();
	config_int["log_level"] = log_level;

	//if config file inputed, use file first
	std::string config_file = result["file"].as<std::string>();
	std::string param_file = result["parameter"].as<std::string>();
	if (config_file.size() > 0) {
		ifstream ifs(config_file);
		if (!ifs) {
			std::cout << "could not open config file:" << config_file << std::endl;
			return 1;
		}
		else {
			Document docRead;
			IStreamWrapper isw(ifs);
			docRead.ParseStream(isw);
			if (docRead.HasParseError()) {
				std::cout << "config file parse error:" << config_file << std::endl;
				return 1;
			}
			else {
				//load grpc config
				config_str["register_center_address"] = docRead["register_center_address"].GetString();

				config_str["location_ip"] = docRead["location_ip"].GetString();
				config_str["grpc_address"] = docRead["grpc_address"].GetString();

				config_int["heartbeat_every_seconds"] = docRead["heartbeat_every_seconds"].GetInt();
			}
		}
	}

	BackTraderCN::StrategyMeanReverse strategy(std::string("mean_reverse"), config_str, config_int, config_double);
	strategy.load(config_file, param_file);
	strategy.init();

	strategy.run();
	return 0;
}
